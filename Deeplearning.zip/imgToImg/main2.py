import tensorflow as tf
import cv2
import numpy as np
import matplotlib.pyplot as plt


model = tf.keras.models.load_model('grayscale_to_color_model.h5')


def load_and_preprocess_image(img_path, target_size=(128, 128)):

    img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)


    img = cv2.resize(img, target_size)

    img = img / 255.0


    img = np.expand_dims(img, axis=-1)
    img = np.expand_dims(img, axis=0)
    return img


def colorize_image(model, grayscale_img):
    colorized_img = model.predict(grayscale_img)
    colorized_img = (colorized_img + 1) / 2.0
    return colorized_img


def save_or_display_image(colorized_img):
    colorized_img = np.squeeze(colorized_img, axis=0)


    colorized_img = cv2.cvtColor(colorized_img, cv2.COLOR_RGB2BGR)


    cv2.imshow('Colorized Image', colorized_img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()



grayscale_img = load_and_preprocess_image('0002.png')


colorized_img = colorize_image(model, grayscale_img)


save_or_display_image(colorized_img)
